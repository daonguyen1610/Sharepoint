
![timeline](https://user-images.githubusercontent.com/19437310/129636998-fdce3cd7-5860-4e63-9d37-a61a53ea60f8.gif)
🎥 https://www.youtube.com/watch?v=lYE7NXTDPJY

Assigned To - Person type column (multi-select) 

Approval Timeline - Multi line text column

Approval Comments - Multi line text column

Approval Pending Since - Single line of text column

**Make sure to match the SharePoint column internal names in JSON with your lists internal column names.**



