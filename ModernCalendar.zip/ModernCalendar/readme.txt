YouTube video walkthrough - https://www.youtube.com/watch?v=fhwAXYvgORs

Use the Events List on a Modern SharePoint Team or Communication Site
