YouTube video walkthrough - https://youtu.be/fb0ePBrifP0

Use Asset Manager Microsoft Lists template

Validation formula:
=IF(AND(Status="In Use",ISBLANK([Due date])),FALSE,TRUE)
